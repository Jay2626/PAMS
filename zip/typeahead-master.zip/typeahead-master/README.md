# typeahead
Multiword predictive/autocomplete typeahead using AngularJS 

This widget is a modification over bootstraps's typeahead widget with following extra features:

- Mutiword support
- Dynamic suggestions popup  
-  Highlight matching text in suggestions
- User friendly functionalities
- Mock API for testing with dynamic random word generation

Check demo at https://ayansome1.github.io/typeahead/

describe('ctPointLabels', function () {
  'use strict';

  beforeEach(function () {

  });

  afterEach(function () {

  });

  it('should be defined in chartist', function () {
    expect(window.Chartist.plugins.ctPointLabels).toBeDefined();
  });
});
